package com.example.dicoding_submission_restaurant_app_api

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
