class DetailArguments {
  final String id;
  final String name;

  DetailArguments({required this.id, required this.name});
}
